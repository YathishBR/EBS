package com.ebs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
