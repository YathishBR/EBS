package com.ebs.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/*
 * 29/11/2022
 * Admin acces is working fine
 * default pages also working fine
 *  NOTE-
 *  1- Register page not working
 *  2- User access is not working
 */
@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration { 

	//Its a default Spring Security Interface uses to do default Authentication
	
	private static final String[] WHITE_LIST_URLS = {
            "/wc",
            "/home",
            "/admin*",
            "/register*"
    };
	@Autowired
	private UserDetailsService userDetailsService;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(11);
	}
	
	@Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .cors()
                .and()
                .csrf()
                .disable() .authorizeHttpRequests()
                .antMatchers("/ebs/wc","/ebs/home","ebs/register").permitAll()
        		.antMatchers("/ebs/**").hasAuthority("admin")
        		.antMatchers("/ebs/user","/ebs/user/{userName}").hasAuthority("user");
                
//                .antMatchers(WHITE_LIST_URLS).permitAll();
//        http
//		.authorizeRequests()
//		.antMatchers("/ebs/wc","/ebs/home","ebs/register").permitAll()
//		.antMatchers("/ebs/**").hasAuthority("admin")
//		.antMatchers("/ebs/user","/ebs/user/{userName}").hasAuthority("user")
//		.anyRequest()
//		.authenticated()
//		.and()
//		.httpBasic();
//        
        return http.build();
   }

		@Bean
		AuthenticationProvider authenticationProvider() {
			//DAO= Data Access Object
			DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
			provider.setUserDetailsService(userDetailsService);
			provider.setPasswordEncoder(new BCryptPasswordEncoder());
			return provider;
		}

		
//	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.authorizeRequests()
		.antMatchers("/ebs/wc","/ebs/home","ebs/register").permitAll()
		.antMatchers("/ebs/**").hasAuthority("admin")
		.antMatchers("/ebs/user","/ebs/user/{userName}").hasAuthority("user")
		.anyRequest()
		.authenticated()
		.and()
		.httpBasic();
	}




}
